
import openai
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

# توکن ربات تلگرام شما
TELEGRAM_TOKEN = "7884586968:AAH1Gq-RqR9473HB-PkJ-FnOg4NFEOiQi1k"
# کلید API OpenAI
OPENAI_API_KEY = "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"

# تنظیم کلید API OpenAI
openai.api_key = OPENAI_API_KEY

def start(update: Update, context: CallbackContext) -> None:
    update.message.reply_text('سلام! من ربات GPT-4 هستم. بپرسید هرچی می‌خواهید!')

def chat_with_gpt(update: Update, context: CallbackContext) -> None:
    user_message = update.message.text

    # ارسال درخواست به OpenAI
    response = openai.Completion.create(
        model="gpt-4",
        prompt=user_message,
        max_tokens=100
    )
    
    # پاسخ از GPT-4
    reply = response.choices[0].text.strip()
    update.message.reply_text(reply)

def main() -> None:
    # ساخت اپدیت‌کننده و دیسپاچر برای ربات
    updater = Updater(TELEGRAM_TOKEN)

    dispatcher = updater.dispatcher

    # افزودن هندلر برای دستور start
    dispatcher.add_handler(CommandHandler("start", start))

    # هندلر برای پیام‌های متنی
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, chat_with_gpt))

    # شروع ربات
    updater.start_polling()

    # نگه داشتن ربات در حال اجرا
    updater.idle()

if __name__ == '__main__':
    main()
