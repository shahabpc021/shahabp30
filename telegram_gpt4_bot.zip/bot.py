import os
import openai
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler

# تنظیم توکن‌ها
TELEGRAM_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'
OPENAI_API_KEY = 'YOUR_OPENAI_API_KEY'
openai.api_key = OPENAI_API_KEY

def start(update, context):
    keyboard = [[InlineKeyboardButton("نمونه کد", callback_data='code'),
                 InlineKeyboardButton("شماتیک گرافیکی", callback_data='graphic')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('سلام! یکی از گزینه‌ها رو انتخاب کن یا سوالتو مستقیم بپرس.', reply_markup=reply_markup)

def button_handler(update, context):
    query = update.callback_query
    query.answer()
    if query.data == 'code':
        query.edit_message_text(text="لطفاً توضیح بده چه کدی می‌خوای برات بنویسم.")
    elif query.data == 'graphic':
        query.edit_message_text(text="چه نوع شماتیکی می‌خوای برات طراحی کنم؟")

def handle_message(update, context):
    user_message = update.message.text
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "شما یک دستیار کدنویسی و گرافیکی هستید."},
                {"role": "user", "content": user_message},
            ]
        )
        bot_reply = response["choices"][0]["message"]["content"]
        update.message.reply_text(bot_reply)
    except Exception as e:
        update.message.reply_text(f"خطا: {e}")

def main():
    updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(button_handler))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()